import HealthKit
import Foundation

/// Centralises every HealthKit read the Pulse PWA needs.
final class HealthKitManager {

    static let shared = HealthKitManager()
    private let store = HKHealthStore()
    private init() {}

    // MARK: - HK type helpers

    private func quantity(_ id: HKQuantityTypeIdentifier) -> HKQuantityType {
        HKQuantityType.quantityType(forIdentifier: id)!
    }

    private var sleepType: HKCategoryType {
        HKCategoryType.categoryType(forIdentifier: .sleepAnalysis)!
    }

    // MARK: - Authorisation

    /// All types the app will read from HealthKit.
    var readTypes: Set<HKSampleType> {
        [
            quantity(.heartRateVariabilitySDNN),
            quantity(.restingHeartRate),
            quantity(.activeEnergyBurned),
            quantity(.oxygenSaturation),
            quantity(.respiratoryRate),
            sleepType
        ]
    }

    /// Request read authorisation for all Pulse data types.
    func requestAuthorization(completion: @escaping (Bool, Error?) -> Void) {
        guard HKHealthStore.isHealthDataAvailable() else {
            completion(false, nil)
            return
        }
        store.requestAuthorization(toShare: [], read: readTypes, completion: completion)
    }

    // MARK: - Generic single-day query helpers

    private func dateRange(for dateString: String) -> (Date, Date)? {
        let fmt = ISO8601DateFormatter()
        fmt.formatOptions = [.withFullDate]
        guard let start = fmt.date(from: dateString) else { return nil }
        let end = Calendar.current.date(byAdding: .day, value: 1, to: start)!
        return (start, end)
    }

    // MARK: - HRV (ms)

    func fetchHRV(date: String, completion: @escaping ([String: Any]) -> Void) {
        guard let (start, end) = dateRange(for: date) else {
            return completion(["value": 0, "unit": "ms"])
        }
        let predicate = HKQuery.predicateForSamples(withStart: start, end: end)
        let sort = NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)
        let query = HKSampleQuery(
            sampleType: quantity(.heartRateVariabilitySDNN),
            predicate: predicate,
            limit: 10,
            sortDescriptors: [sort]
        ) { _, samples, _ in
            guard let samples = samples as? [HKQuantitySample], !samples.isEmpty else {
                return completion(["value": 0, "unit": "ms"])
            }
            // Average the last few overnight readings
            let avg = samples.prefix(6)
                .map { $0.quantity.doubleValue(for: .init(from: "ms")) }
                .reduce(0, +) / Double(min(samples.count, 6))
            completion(["value": Int(avg.rounded()), "unit": "ms"])
        }
        store.execute(query)
    }

    // MARK: - Resting Heart Rate (bpm)

    func fetchRestingHR(date: String, completion: @escaping ([String: Any]) -> Void) {
        guard let (start, end) = dateRange(for: date) else {
            return completion(["value": 0, "unit": "bpm"])
        }
        let predicate = HKQuery.predicateForSamples(withStart: start, end: end)
        let sort = NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)
        let query = HKSampleQuery(
            sampleType: quantity(.restingHeartRate),
            predicate: predicate,
            limit: 1,
            sortDescriptors: [sort]
        ) { _, samples, _ in
            guard let s = (samples as? [HKQuantitySample])?.first else {
                return completion(["value": 0, "unit": "bpm"])
            }
            let bpm = s.quantity.doubleValue(for: HKUnit(from: "count/min"))
            completion(["value": Int(bpm.rounded()), "unit": "bpm"])
        }
        store.execute(query)
    }

    // MARK: - Active Energy (kcal)

    func fetchActiveEnergy(date: String, completion: @escaping ([String: Any]) -> Void) {
        guard let (start, end) = dateRange(for: date) else {
            return completion(["value": 0, "unit": "kcal"])
        }
        let predicate = HKQuery.predicateForSamples(withStart: start, end: end)
        let query = HKStatisticsQuery(
            quantityType: quantity(.activeEnergyBurned),
            quantitySamplePredicate: predicate,
            options: .cumulativeSum
        ) { _, stats, _ in
            let kcal = stats?.sumQuantity()?.doubleValue(for: .kilocalorie()) ?? 0
            completion(["value": Int(kcal.rounded()), "unit": "kcal"])
        }
        store.execute(query)
    }

    // MARK: - Blood Oxygen (%)

    func fetchSpO2(date: String, completion: @escaping ([String: Any]) -> Void) {
        guard let (start, end) = dateRange(for: date) else {
            return completion(["value": 0, "unit": "%"])
        }
        let predicate = HKQuery.predicateForSamples(withStart: start, end: end)
        let sort = NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)
        let query = HKSampleQuery(
            sampleType: quantity(.oxygenSaturation),
            predicate: predicate,
            limit: 10,
            sortDescriptors: [sort]
        ) { _, samples, _ in
            guard let samples = samples as? [HKQuantitySample], !samples.isEmpty else {
                return completion(["value": 0, "unit": "%"])
            }
            let avg = samples.prefix(5)
                .map { $0.quantity.doubleValue(for: .percent()) * 100 }
                .reduce(0, +) / Double(min(samples.count, 5))
            completion(["value": Int(avg.rounded()), "unit": "%"])
        }
        store.execute(query)
    }

    // MARK: - Respiratory Rate (br/min)

    func fetchRespiratoryRate(date: String, completion: @escaping ([String: Any]) -> Void) {
        guard let (start, end) = dateRange(for: date) else {
            return completion(["value": 0, "unit": "brpm"])
        }
        let predicate = HKQuery.predicateForSamples(withStart: start, end: end)
        let sort = NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)
        let query = HKSampleQuery(
            sampleType: quantity(.respiratoryRate),
            predicate: predicate,
            limit: 10,
            sortDescriptors: [sort]
        ) { _, samples, _ in
            guard let samples = samples as? [HKQuantitySample], !samples.isEmpty else {
                return completion(["value": 0, "unit": "brpm"])
            }
            let unit = HKUnit(from: "count/min")
            let avg = samples.prefix(6)
                .map { $0.quantity.doubleValue(for: unit) }
                .reduce(0, +) / Double(min(samples.count, 6))
            completion(["value": Double(round(avg * 10) / 10), "unit": "brpm"])
        }
        store.execute(query)
    }

    // MARK: - Sleep Analysis

    /// Returns a structured sleep summary for the night that ends on `date`.
    /// We look back 16 hours from noon on `date` to capture the preceding night.
    func fetchSleep(date: String, completion: @escaping ([String: Any]) -> Void) {
        let fmt = ISO8601DateFormatter()
        fmt.formatOptions = [.withFullDate]
        guard let noon = fmt.date(from: date).map({ cal -> Date in
            Calendar.current.date(bySettingHour: 12, minute: 0, second: 0, of: $0)!
        }) else { return completion(emptySleep()) }

        let start = Calendar.current.date(byAdding: .hour, value: -20, to: noon)!
        let end   = noon
        let predicate = HKQuery.predicateForSamples(withStart: start, end: end)
        let sort = NSSortDescriptor(key: HKSampleSortIdentifierStartDate, ascending: true)

        let query = HKSampleQuery(
            sampleType: sleepType,
            predicate: predicate,
            limit: HKObjectQueryNoLimit,
            sortDescriptors: [sort]
        ) { [weak self] _, samples, _ in
            guard let self = self,
                  let samples = samples as? [HKCategorySample], !samples.isEmpty else {
                return completion(self?.emptySleep() ?? [:])
            }
            completion(self.processSleepSamples(samples))
        }
        store.execute(query)
    }

    private func emptySleep() -> [String: Any] {
        ["total":0,"awake":0,"light":0,"deep":0,"rem":0,
         "bedH":0,"bedM":0,"wakeH":0,"wakeM":0,"resp":0,"spo2":0]
    }

    private func processSleepSamples(_ samples: [HKCategorySample]) -> [String: Any] {
        var awakeMins = 0, lightMins = 0, deepMins = 0, remMins = 0

        for s in samples {
            let mins = Int(s.endDate.timeIntervalSince(s.startDate) / 60)
            switch HKCategoryValueSleepAnalysis(rawValue: s.value) {
            case .awake:                awakeMins += mins
            case .asleepCore:           lightMins += mins
            case .asleepDeep:           deepMins  += mins
            case .asleepREM:            remMins   += mins
            case .inBed:                break  // ignore in-bed only
            default:
                // Legacy .asleep maps to light for older Apple Watch data
                if s.value == HKCategoryValueSleepAnalysis.asleep.rawValue {
                    lightMins += mins
                }
            }
        }

        let total = lightMins + deepMins + remMins
        let bedDate  = samples.first!.startDate
        let wakeDate = samples.last!.endDate
        let cal = Calendar.current

        return [
            "total":  total,
            "awake":  awakeMins,
            "light":  lightMins,
            "deep":   deepMins,
            "rem":    remMins,
            "bedH":   cal.component(.hour,   from: bedDate),
            "bedM":   cal.component(.minute, from: bedDate),
            "wakeH":  cal.component(.hour,   from: wakeDate),
            "wakeM":  cal.component(.minute, from: wakeDate),
            "resp":   0,   // filled by respiratory rate query
            "spo2":   0    // filled by SpO2 query
        ]
    }
}
