import UIKit
import WebKit
import HealthKit

final class ViewController: UIViewController {

    // MARK: - Properties

    private var webView: WKWebView!
    private var bridge: HealthKitBridge!

    // MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 0.04, green: 0.04, blue: 0.06, alpha: 1)
        setupWebView()
        loadPWA()
    }

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    // MARK: - WebView setup

    private func setupWebView() {
        // Content controller for the HealthKit bridge
        let contentController = WKUserContentController()

        // Configuration
        let config = WKWebViewConfiguration()
        config.userContentController = contentController
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []

        // Preferences
        let prefs = WKWebpagePreferences()
        prefs.allowsContentJavaScript = true
        config.defaultWebpagePreferences = prefs

        // Build the WebView
        webView = WKWebView(frame: .zero, configuration: config)
        webView.translatesAutoresizingMaskIntoConstraints = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.isOpaque = false
        webView.backgroundColor = .clear
        webView.scrollView.backgroundColor = .clear
        webView.navigationDelegate = self

        // Add to view
        view.addSubview(webView)
        NSLayoutConstraint.activate([
            webView.topAnchor.constraint(equalTo: view.topAnchor),
            webView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
        ])

        // Register bridge AFTER webView exists
        bridge = HealthKitBridge(webView: webView)
        contentController.add(bridge, name: "healthkit")
    }

    // MARK: - Load PWA

    private func loadPWA() {
        // If you bundle index.html inside the app, use this:
        if let url = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "www") {
            webView.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
            return
        }

        // Or load from a remote URL (useful during dev):
        // let url = URL(string: "https://your-deployed-pulse-url.com")!
        // webView.load(URLRequest(url: url))

        // Fallback: show error
        let html = "<body style='background:#0a0a0f;color:#fff;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;'><p>Could not load Pulse. Make sure index.html is in the www/ folder.</p></body>"
        webView.loadHTMLString(html, baseURL: nil)
    }
}

// MARK: - WKNavigationDelegate

extension ViewController: WKNavigationDelegate {
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        // PWA loaded — it will call requestAuthorization itself on boot
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        print("❌ WebView navigation failed: \(error.localizedDescription)")
    }
}
