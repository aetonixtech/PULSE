# Pulse — iOS Native Wrapper

This folder contains the Swift/Xcode wrapper that hosts the Pulse PWA
in a WKWebView and bridges it to Apple HealthKit for real health data.

---

## Project structure

```
pulse-ios/
├── Pulse.xcodeproj/
│   └── project.pbxproj
└── Pulse/
    ├── AppDelegate.swift        — App entry point
    ├── ViewController.swift     — WKWebView host
    ├── HealthKitManager.swift   — All HK queries (HRV, HR, sleep, SpO2, etc.)
    ├── HealthKitBridge.swift    — JS ↔ Swift message handler
    ├── Info.plist               — HealthKit usage strings & entitlements
    └── Pulse.entitlements       — com.apple.developer.healthkit
```

---

## Setup in Xcode (takes ~10 minutes)

### 1. Open the project
```
open Pulse.xcodeproj
```

### 2. Add your Team & Bundle ID
- Select the **Pulse** target → **Signing & Capabilities**
- Set your **Team** (Apple Developer account)
- Change **Bundle Identifier** from `com.yourteam.pulse` to something unique, e.g. `com.yourname.pulse`

### 3. Enable HealthKit capability
- Still in Signing & Capabilities, click **+**
- Add **HealthKit**
- Xcode will merge the entitlement automatically

### 4. Add the PWA files
- Create a folder called `www` inside the `Pulse/` directory
- Copy your `index.html` (and any assets) into `Pulse/www/`
- In Xcode: **File → Add Files to "Pulse"** → select the `www` folder
- Make sure **"Create folder references"** is selected (blue folder icon)
- This makes `index.html` available as `Bundle.main.url(forResource:subdirectory:)`

### 5. Build & run on a real device
HealthKit **does not work on the Simulator**.
- Plug in your iPhone
- Select it as the run destination
- Press ⌘R

On first launch the app will request HealthKit permission for:
- Heart Rate Variability
- Resting Heart Rate
- Active Energy Burned
- Sleep Analysis
- Blood Oxygen
- Respiratory Rate

---

## How the bridge works

```
PWA (JS)                          Swift
────────                          ─────
window.webkit.messageHandlers
  .healthkit.postMessage({        ──►  HealthKitBridge.userContentController()
    id: 42,                              dispatches to HealthKitManager
    type: "query",
    options: {
      type: "HKQuantityType...HRV",
      date: "2025-05-21"
    }
  })

window.onHealthKitData(42, data)  ◄──  bridge.reply(id:data:)
                                         evaluates JS on main thread
```

Every call is async and non-blocking. The PWA already contains
`window.onHealthKitData` and the full `requestHK()` promise wrapper —
no changes needed to `index.html`.

---

## Distributing via TestFlight

1. Archive: **Product → Archive**
2. In Organizer: **Distribute App → TestFlight**
3. Add testers in App Store Connect

---

## Data types & sources

| Metric       | HK Type                                      | Source            |
|--------------|----------------------------------------------|-------------------|
| HRV          | HeartRateVariabilitySDNN                     | Apple Watch       |
| Resting HR   | RestingHeartRate                             | Apple Watch / app |
| Active kcal  | ActiveEnergyBurned                           | Apple Watch       |
| Sleep stages | SleepAnalysis (Core/Deep/REM)               | Apple Watch S6+   |
| Blood oxygen | OxygenSaturation                             | Apple Watch S6+   |
| Resp. rate   | RespiratoryRate                              | Apple Watch S4+   |

Sleep stages (Deep/REM) require **Apple Watch Series 6 or later**.
Older watches write `.asleep` only, which maps to Light in Pulse.

---

## Recovery score formula

```
recScore = (HRV / baseline × 50) + (max(0, 65 − restingHR) / 15 × 30) + 20
```

Baseline is 60 ms by default. You can make this user-configurable in Settings.

---

## Requirements

- Xcode 15+
- iOS 16+ deployment target
- Apple Developer account (free works for device testing; paid needed for TestFlight)
- iPhone with Apple Watch for real HealthKit data
