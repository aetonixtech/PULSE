import WebKit
import Foundation

/// Handles all messages posted by the PWA via:
///   window.webkit.messageHandlers.healthkit.postMessage({ id, type, options })
///
/// Responses are delivered back to JS as:
///   window.onHealthKitData(id, data)
final class HealthKitBridge: NSObject, WKScriptMessageHandler {

    private weak var webView: WKWebView?
    private let hk = HealthKitManager.shared

    init(webView: WKWebView) {
        self.webView = webView
    }

    // MARK: - WKScriptMessageHandler

    func userContentController(
        _ userContentController: WKUserContentController,
        didReceive message: WKScriptMessage
    ) {
        guard
            message.name == "healthkit",
            let body = message.body as? [String: Any],
            let callbackId = body["id"] as? Int,
            let type = body["type"] as? String
        else { return }

        let options = body["options"] as? [String: Any] ?? [:]
        let date    = options["date"] as? String ?? todayString()

        switch type {

        case "authorize":
            hk.requestAuthorization { [weak self] granted, _ in
                self?.reply(id: callbackId, data: ["granted": granted])
            }

        case "query":
            guard let hkType = options["type"] as? String else {
                return reply(id: callbackId, data: [:])
            }
            dispatchQuery(hkType: hkType, date: date, callbackId: callbackId)

        default:
            reply(id: callbackId, data: [:])
        }
    }

    // MARK: - Query dispatch

    private func dispatchQuery(hkType: String, date: String, callbackId: Int) {
        switch hkType {

        case "HKQuantityTypeIdentifierHeartRateVariabilitySDNN":
            hk.fetchHRV(date: date) { [weak self] in self?.reply(id: callbackId, data: $0) }

        case "HKQuantityTypeIdentifierRestingHeartRate":
            hk.fetchRestingHR(date: date) { [weak self] in self?.reply(id: callbackId, data: $0) }

        case "HKQuantityTypeIdentifierActiveEnergyBurned":
            hk.fetchActiveEnergy(date: date) { [weak self] in self?.reply(id: callbackId, data: $0) }

        case "HKCategoryTypeIdentifierSleepAnalysis":
            // Sleep needs SpO2 and resp rate merged in
            let group = DispatchGroup()
            var sleepResult:  [String: Any] = [:]
            var spo2Result:   [String: Any] = [:]
            var respResult:   [String: Any] = [:]

            group.enter()
            hk.fetchSleep(date: date)         { sleepResult = $0; group.leave() }
            group.enter()
            hk.fetchSpO2(date: date)          { spo2Result  = $0; group.leave() }
            group.enter()
            hk.fetchRespiratoryRate(date: date){ respResult  = $0; group.leave() }

            group.notify(queue: .main) { [weak self] in
                var merged = sleepResult
                merged["spo2"] = spo2Result["value"] as? Int ?? 0
                merged["resp"] = respResult["value"] as? Double ?? 0.0
                self?.reply(id: callbackId, data: merged)
            }

        case "HKQuantityTypeIdentifierOxygenSaturation":
            hk.fetchSpO2(date: date) { [weak self] in self?.reply(id: callbackId, data: $0) }

        case "HKQuantityTypeIdentifierRespiratoryRate":
            hk.fetchRespiratoryRate(date: date) { [weak self] in self?.reply(id: callbackId, data: $0) }

        default:
            reply(id: callbackId, data: [:])
        }
    }

    // MARK: - Reply helper

    private func reply(id: Int, data: [String: Any]) {
        guard let webView = webView else { return }
        guard let jsonData = try? JSONSerialization.data(withJSONObject: data),
              let jsonString = String(data: jsonData, encoding: .utf8) else { return }
        let js = "window.onHealthKitData(\(id), \(jsonString));"
        DispatchQueue.main.async {
            webView.evaluateJavaScript(js, completionHandler: nil)
        }
    }

    // MARK: - Helpers

    private func todayString() -> String {
        let fmt = ISO8601DateFormatter()
        fmt.formatOptions = [.withFullDate]
        return fmt.string(from: Date())
    }
}
